Kylin DBAPI Driver and Sqlalchemy Dialect
==============================

Installation
------------

To install this driver run::

    $ pip install pykylin

or from source::

    $ pip install -r ./requirements.txt
    $ python setup.py install


More info
---------

 * http://kylin.incubator.apache.org/
 * http://www.sqlalchemy.org/


Authors
-------

 * Wu Xiang